#ifndef __ALIYUN_MQTT_H_
#define __ALIYUN_MQTT_H_
/*
��void systick_isr(void)�ŵ��δ�ʱ���ж�
*/
#include "sys.h"

#define ESP_WIFI_SSID										"bishe"
#define ESP_WIFI_PASSWORD								"12345678"

#define ESP_RST_GPIO_CLK_ENABLE					RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);				
#define ESP_RST_GPIO_PORT               GPIOA
#define ESP_RST_PIN                     GPIO_Pin_1

#define DEV_NAME "ESP82666648"
#define PRODUCT_KEY "cuuh59ix97tjm3Wr"
#define DEV_KEY "FnabZ9U9OkVsVi4"
#define DEV_SECRET "9AE2A40E1706FD62557A6F7B171F5BF7"
#define BROKER_ADDRESS "dmp-mqtt.cuiot.cn"
#define MQTT_PORT "1883"
#define PUBLISH_TOPIC	"$sys/cuuh59ix97tjm3Wr/FnabZ9U9OkVsVi4/property/batch"
#define PUBLISH_TOPIC_EVENT "$sys/cuuh59ix97tjm3Wr/FnabZ9U9OkVsVi4/event/pub"
#define SUBSCRIBE_TOPIC	"$sys/cuuh59ix97tjm3Wr/FnabZ9U9OkVsVi4/property/set"
#define SUBSCRIBE_TOPIC_SERVICE "$sys/cuuh59ix97tjm3Wr/FnabZ9U9OkVsVi4/service/pub"

/*******************************************************************************
* Function Name  : AliYun_Mqtt_Init
* Description    : ������ƽ̨MQTT��ʼ��
* Input          : None
* Output         : None
* Return         : None
* Note			 : None
*******************************************************************************/
void AliYun_Mqtt_Init(void);

/*******************************************************************************
* Function Name  : AliYun_Mqtt_Connect
* Description    : ������ƽ̨MQTT����
* Input          : None
* Output         : None
* Return         : None
* Note			 : None
*******************************************************************************/
void AliYun_Mqtt_Connect(void);


void AliYun_Connect_Progress(void);

#endif
