/***************************** (C) COPYRIGHT ************************************
* File Name          : utils_hmac.h
* Author             : �ǹ�Ƕ��ʽ
* Version            : V1.0
* Date               : 06/01/2019
* Description        : ����Ѱ�ҵĿ�Դ����  
* Note               : NONE
********************************************************************************
* �Ա�����: https://shop148702745.taobao.com/
* ������̳: www.feifanembed.com
* QQȺ:542830257
********************************************************************************/

#ifndef UTILS_HMAC_H_
#define UTILS_HMAC_H_

#include "stdio.h"
#include "stdint.h"
#include "stdlib.h"
#include "string.h"

void utils_hmac_md5(const char *msg, int msg_len, char *digest, const char *key, int key_len);
void utils_hmac_sha1(const char *msg, int msg_len, char *digest, const char *key, int key_len);
void utils_hmac_sha256(const char *msg, int msg_len, char *digest, const char *key, int key_len);
int base64_decode( const char * base64, unsigned char * bindata );

#endif

