#ifndef __DHT11_H__
#define	__DHT11_H__
#include "sys.h"

typedef struct
{
	uint8_t  humi_high8bit;		//ԭʼ���ݣ�ʪ�ȸ�8λ
	uint8_t  humi_low8bit;	 	//ԭʼ���ݣ�ʪ�ȵ�8λ
	uint8_t  temp_high8bit;	 	//ԭʼ���ݣ��¶ȸ�8λ
	uint8_t  temp_low8bit;	 	//ԭʼ���ݣ��¶ȸ�8λ
	uint8_t  check_sum;	 	    //У���
  uint8_t    humidity;        //ʵ��ʪ��
  int16_t    temperature;     //ʵ���¶�  
} DHT11_Data_TypeDef;

#define DHT11_GPIO_CLK_ENABLE              RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE)
#define DHT11_GPIO_PORT                    GPIOC
#define DHT11_GPIO                         GPIO_Pin_6

#define DHT11_Data_in	PCin(6)
#define DHT11_Dout PCout(6)
void DHT11_Init( void );
uint8_t DHT11_Read_TempAndHumidity(DHT11_Data_TypeDef * DHT11_Data);

#endif 
