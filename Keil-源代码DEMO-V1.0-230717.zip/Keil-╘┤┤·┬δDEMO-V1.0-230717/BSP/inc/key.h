#ifndef __KEY_H
#define __KEY_H	 
#include "sys.h"

void KEY_Init(void);//IO��ʼ��
	    
#endif
