#ifndef BH1750_H
#define BH1750_H
#include "sys.h"

#define  BH1750_SCL_GPIO_PORT  GPIOB
#define  BH1750_SCL_GPIO_PIN   GPIO_Pin_15

#define  BH1750_SDA_GPIO_PORT  GPIOB
#define  BH1750_SDA_GPIO_PIN   GPIO_Pin_14

#define BH1750_read  0x47  //BH1750�Ķ���ַ
#define BH1750_write 0x46  //BH1750��д��ַ
#define SlaveAddress 0x46

#define  BH1750_SCL_HIGH()   	PBout(15)=1
#define  BH1750_SCL_LOW()   	PBout(15)=0
#define  BH1750_SDA_HIGH()   	PBout(14)=1
#define  BH1750_SDA_LOW()   	PBout(14)=0

#define  BH1750_SDA_READ()    PBin(14)

uint32_t BH1750_Read(void);
void BH1750_Write(uint8_t a);
void BH1750_Init(void);
uint16_t Get_BH1750_Value(void);
uint16_t BH1750_IIC_Read_Byte(uint8_t ack);
void BH1750_IIC_Send_Byte(uint8_t txd);
void BH1750_IIC_NAck(void);
void BH1750_IIC_Ack(void);
uint8_t BH1750_IIC_Wait_Ack(void);
void BH1750_IIC_Stop(void);
void BH1750_IIC_Start(void);

#endif

