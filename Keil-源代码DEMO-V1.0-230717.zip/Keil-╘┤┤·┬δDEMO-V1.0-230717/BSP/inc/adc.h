#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"


/* PC5 */
#define AO1_Channel ADC_Channel_15


void Adc_Init(void);
u16  Get_Adc(u8 ch); 

#endif 

